/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


export const L_hr=`{
    "name": "dean",
    "login":{
        "login":"Prijava na sustav",
        "login_short":"Prijava",
        "logout":"Odjava iz sustava",
        "username":"Korisničko ime",
        "password":"Lozinka",
        "loginfailed":"Prijava na sustav nije uspjela!${'\\n'}Provjerite korisničko ime i lozinku i pokušajte ponovno."
    },
    "editform":{
        "nekretninaEditform":{
            "vlasnistvo":"DA"
        },
        "nekretninetable":{
            "vlasnistvo":"DA"
        },
        "vozilatasklist_table":{
            "rjeseno":"DA"
        },
        "odrzavanjeprostoravrstaEditform":{
        }
    },
    "table":{
        "tablesearch":"Pretraga tablice",
        "userstable":{
            "name":"Ime",
            "surname":"Prezime",
            "title":"Titula",
            "username":"Korisničko ime"
        },
        "studyPrograms_table":{
            "id":"id",
            "name":"name",
            "description":"description"
        },
        "StudyCompetence_TABLE":{
            "id":"id",
            "name":"name",
            "description":"description"
        },
        "StudyModule_TABLE":{
            "id":"id",
            "name":"name",
            "description":"description"
        }
    },
    "menu":{
        "mnuHome":{
            "caption":"Home",
            "subitems":{
            }
        }
    }
}`;
