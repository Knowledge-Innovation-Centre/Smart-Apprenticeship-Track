-- drop table USER_PERMISSIONS;
-- drop table USERS;
-- drop table ORGANIZATION;
-- drop table STUDY_COMPETENCES;
-- drop table STUDY_PROGRAMS;
-- drop table SCHOOLS;



create table SCHOOLS (
	id NVARCHAR(64) NOT NULL UNIQUE,
	CONSTRAINT SCHOOLS_PK PRIMARY KEY (id)
);

insert into SCHOOLS (id) values ('TestSchool');

create table USERS (
	username NVARCHAR(64) NOT NULL,
	password NVARCHAR(64) NOT NULL,
	school_id NVARCHAR(64) NOT NULL,
	CONSTRAINT USERS_PK PRIMARY KEY (username),
	CONSTRAINT USERS_SCHOOLS_FK FOREIGN KEY (school_id) REFERENCES SCHOOLS(id)
);

create table USER_PERMISSIONS(
	id INT NOT NULL AUTO_INCREMENT,
	USERNAME NVARCHAR(64) NOT NULL,
	ROLE NVARCHAR(64),
	CONSTRAINT USER_PERMISSIONS_PK PRIMARY KEY (id),
	CONSTRAINT USER_PERMISSIONS_USERS_FK FOREIGN KEY (USERNAME) REFERENCES USERS(username)
);

insert into USERS (username,password,school_id) values ('admin','admin','TestSchool');
insert into USER_PERMISSIONS (USERNAME,role) values ('admin','ROLE_ADMIN');

-- insert into USER_PERMISSIONS (USERNAME,role) values ('admin','ROLE_STUDENT')
-- insert into USER_PERMISSIONS (USERNAME,role) values ('admin','ROLE_TEACHER')
-- insert into USER_PERMISSIONS (USERNAME,role) values ('admin','ROLE_EMPLOYER')
-- insert into USER_PERMISSIONS (USERNAME,role) values ('admin','ROLE_MENTOR')

COMMIT;

-- select * from USERS
-- select * from USER_PERMISSIONS


create table ORGANIZATION (
	id INT NOT NULL AUTO_INCREMENT,
	orgtype NVARCHAR(64) NOT NULL,
	name NVARCHAR(64) NOT NULL,
	cityname NVARCHAR(128) NOT NULL,
	cityzipcode NVARCHAR(64) NOT NULL,
	streetname NVARCHAR(256) NOT NULL,
	contact_username NVARCHAR(64)  NOT NULL,
	CONSTRAINT ORGANIZATION_PK PRIMARY KEY (id),
	CONSTRAINT ORGANIZATION_USERS_FK FOREIGN KEY (contact_username) REFERENCES USERS(username)
);

alter TABLE ORGANIZATION add school_id NVARCHAR(64) NOT NULL;
alter table ORGANIZATION 
	add constraint ORGANIZATION__SCHOOL__FK
	foreign key (school_id) 
	references SCHOOLS(id) 
	on delete no action 
	on update cascade;

alter table USERS add phone NVARCHAR(64);
alter table USERS add email NVARCHAR(64);
alter table USERS add cityname NVARCHAR(128);
alter table USERS add cityzipcode NVARCHAR(64);
alter table USERS add streetname NVARCHAR(256);
alter table USERS add contact_username NVARCHAR(64);


create table STUDY_PROGRAMS(
	id INT NOT NULL AUTO_INCREMENT,
	school_id NVARCHAR(64) NOT NULL,
	CONSTRAINT STUDY_PROGRAMS_PK PRIMARY KEY (id),
	CONSTRAINT STUDY_PROGRAMS_SCHOOLS_FK FOREIGN KEY (school_id) REFERENCES SCHOOLS(id)
);

alter table STUDY_PROGRAMS add study_program_id INT;
alter table STUDY_PROGRAMS 
	add constraint STUDY_PROGRAMS__STUDY_PROGRAMS__FK
	foreign key (study_program_id) 
	references STUDY_PROGRAMS(id) 
	on delete no action 
	on update cascade;

alter TABLE STUDY_PROGRAMS add name NVARCHAR(64);
alter TABLE STUDY_PROGRAMS add description NVARCHAR(256);

create table STUDY_COMPETENCES(
	id INT NOT NULL AUTO_INCREMENT,
	name NVARCHAR(64) NOT NULL,
	description NVARCHAR(256) NOT NULL,
	study_program_id INT NOT NULL,
	CONSTRAINT STUDY_PROGRAMS_PK PRIMARY KEY (id),
	CONSTRAINT STUDY_COMPETENCES__STUDY_PROGRAMS__FK FOREIGN KEY (study_program_id) REFERENCES STUDY_PROGRAMS(id)
);


create table INTERNSHIP_STUDYPROGRAMS_MAP(
	id INT NOT NULL AUTO_INCREMENT,
	CONSTRAINT STUDY_PROGRAMS_PK PRIMARY KEY (id),
	organization_id INT NOT NULL,
	study_program_id INT NOT NULL,
	CONSTRAINT INTERNSHIP_STUDYPROGRAMS_MAP__STUDY_PROGRAMS__FK FOREIGN KEY (study_program_id) REFERENCES STUDY_PROGRAMS(id),
	CONSTRAINT INTERNSHIP_STUDYPROGRAMS_MAP__ORGANIZATION__FK FOREIGN KEY (organization_id) REFERENCES ORGANIZATION(id)
);


create table INTERNSHIP_AGREEMENT(
	id INT NOT NULL AUTO_INCREMENT,
	organization_id INT NOT NULL,
	student_username NVARCHAR(64) NOT NULL,
	period_begin DATE not null,
	period_end DATE not null,
	study_program_id INT NOT NULL,
	CONSTRAINT INTERNSHIP_AGREEMENT_PK PRIMARY KEY (id),
	CONSTRAINT INTERNSHIP_AGREEMENT__student__FK FOREIGN KEY (student_username) REFERENCES USERS(username),
	CONSTRAINT INTERNSHIP_AGREEMENT__STUDY_PROGRAMS__FK FOREIGN KEY (study_program_id) REFERENCES STUDY_PROGRAMS(id),
	CONSTRAINT INTERNSHIP_AGREEMENT__ORGANIZATION__FK FOREIGN KEY (organization_id) REFERENCES ORGANIZATION(id)
);


alter table USERS add COLUMN organization_id int NULL;
alter table USERS 
	add constraint USERS__ORGANIZATION__FK
	foreign key (organization_id) 
	references ORGANIZATION(id) 
	on delete no action 
	on update cascade;

ALTER TABLE ORGANIZATION MODIFY contact_username NVARCHAR(64) NULL;

create table INTERNSHIP_STUDYPROGRAMS_COMPETENCES_MAP(
	id INT NOT NULL AUTO_INCREMENT,
	internship_studyprograms_map_id INT NOT NULL,
	CONSTRAINT INTERNSHIP_STUDYPROGRAMS_COMPETENCES_MAP_PK PRIMARY KEY (id),
	CONSTRAINT INTERNSHIP_SP_COMP_MAP__INTERNSHIP_SP__FK FOREIGN KEY (internship_studyprograms_map_id) REFERENCES INTERNSHIP_STUDYPROGRAMS_MAP(id)
);

alter table INTERNSHIP_STUDYPROGRAMS_COMPETENCES_MAP add study_competences_id INT;
alter table INTERNSHIP_STUDYPROGRAMS_COMPETENCES_MAP
	add constraint INTERNSHIP_SP_COMP__SP__FK
	foreign key (study_competences_id) 
	references STUDY_COMPETENCES(id) 
	on delete no action 
	on update cascade;


alter table INTERNSHIP_AGREEMENT add school_id NVARCHAR(64) NOT NULL;
alter table INTERNSHIP_AGREEMENT
	add constraint INTERNSHIPAGREEMENT_SCHOOL__FK
	foreign key (school_id) 
	references SCHOOLS(id) 
	on delete no action 
	on update cascade;

create table AGREEMENT_ARTICLES_TEMPLATE(
	id INT NOT NULL AUTO_INCREMENT,
	school_id NVARCHAR(64) NOT NULL,
	ordnum INT NOT NULL default 9999,
	content NVARCHAR(512) NOT NULL,
	CONSTRAINT AGREEMENT_ARTICLES_TEMPLATE_PK PRIMARY KEY (id),
	CONSTRAINT AGREEMENT_ARTICLES_TEMPLATE__SCHOOLS_FK FOREIGN KEY (school_id) REFERENCES SCHOOLS(id)
);

create table INTERNSHIP_AGREEMENT_ARTICLES(
	id INT NOT NULL AUTO_INCREMENT,
	school_id NVARCHAR(64) NOT NULL,
	internshipagreement_id INT NOT NULL,
	ordnum INT NOT NULL default 9999,
	content NVARCHAR(512) NOT NULL,
	CONSTRAINT AGREEMENT_ARTICLES_TEMPLATE_PK PRIMARY KEY (id),
	CONSTRAINT AGREEMENT_ARTICLES_TEMPLATE__SCHOOLS__FK FOREIGN KEY (school_id) REFERENCES SCHOOLS(id),
	CONSTRAINT AGREEMENT_ARTICLES_TEMPLATE__INTERNSHIP_AGREEMENT__FK FOREIGN KEY (internshipagreement_id) REFERENCES INTERNSHIP_AGREEMENT(id)
);

alter table INTERNSHIP_AGREEMENT add version_num INT DEFAULT -1;
alter table INTERNSHIP_AGREEMENT_ARTICLES add version_num INT DEFAULT -1;

create table INTERNSHIP_AGREEMENT_SIGNATURES(
	id INT NOT NULL AUTO_INCREMENT,
	internship_agreement_id INT NOT NULL,
	username NVARCHAR(64) NOT NULL,
	signed_role NVARCHAR(64) NOT NULL,
	signed_date DATETIME not null DEFAULT now(),
	signed_version INT NOT NULL,
	content NVARCHAR(512) NOT NULL,
	CONSTRAINT INTERNSHIP_AGREEMENT_SIGNATURES PRIMARY KEY (id),
	CONSTRAINT INTERNSHIP_AGREEMENT_SIGNATURES__INTERNSHIP_AGREEMENT__FK FOREIGN KEY (internship_agreement_id) REFERENCES INTERNSHIP_AGREEMENT(id),
	CONSTRAINT INTERNSHIP_AGREEMENT_SIGNATURES__USERS__FK FOREIGN KEY (username) REFERENCES USERS(username)
);

alter table INTERNSHIP_AGREEMENT MODIFY COLUMN version_num INT NOT NULL default 1;

alter table INTERNSHIP_AGREEMENT_SIGNATURES DROP COLUMN content;

alter table INTERNSHIP_AGREEMENT modify column period_begin DATE null;
alter table INTERNSHIP_AGREEMENT modify column period_end DATE null;

CREATE TABLE `INTERNSHIPAGREEMENT_STUDYCOMPETENCES_MAP` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `internship_agreement_id` int(11) NOT NULL,
  `study_competences_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `IIASCMAP__STUDYCOMPETENCEST__FK` FOREIGN KEY (`study_competences_id`) REFERENCES `STUDY_COMPETENCES` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
);


alter table INTERNSHIPAGREEMENT_STUDYCOMPETENCES_MAP
    add constraint INTERNSHIPAGT_STUDYCOMPETENCES_MAP__INTERNSHIPAGREEMENT__FK
    foreign key (internship_agreement_id) references INTERNSHIP_AGREEMENT(id)
    on delete no action 
    on update cascade;

create table INTERNSHIPAGREEMENT_GRADES(
	id INT NOT NULL AUTO_INCREMENT,
	internship_agreement_id int not null,
	study_competences_id int not null,
	grade int null,
	grade_text NVARCHAR(512) null,
	mentor_username NVARCHAR(64) not null,
	PRIMARY KEY (id),
	CONSTRAINT IA_GRADES__INTERNSHIPAGREEMENT__FK FOREIGN KEY (internship_agreement_id) REFERENCES INTERNSHIP_AGREEMENT (id) ON DELETE NO ACTION ON UPDATE CASCADE,
	CONSTRAINT IA_GRADES__INTERNSHIPAGREEMENT_STUDYCOMPETENCES__FK FOREIGN KEY (internship_agreement_id) REFERENCES INTERNSHIPAGREEMENT_STUDYCOMPETENCES_MAP (id) ON DELETE NO ACTION ON UPDATE CASCADE
);

Create table FILEUPLOAD(
	id INT NOT NULL AUTO_INCREMENT,
	owner_username NVARCHAR(64) NOT NULL,
	table_name VARCHAR(64) NOT NULL,
	table_id integer NULL,
	bytes BLOB,
	mime VARCHAR(128) NOT NULL,
	filename VARCHAR(256) NOT NULL,
	vrijeme DATETIME not null DEFAULT now(),
	
	CONSTRAINT FILEUPLOAD_PK PRIMARY KEY (id),
	CONSTRAINT FILEUPLOAD_USERS_FK FOREIGN KEY (owner_username) REFERENCES USERS(username)
);

alter table FILEUPLOAD add school_id NVARCHAR(64) NOT NULL;
alter table FILEUPLOAD
	add constraint FILEUPLOAD_SCHOOL__FK
	foreign key (school_id) 
	references SCHOOLS(id) 
	on delete no action 
	on update cascade;


alter table FILEUPLOAD drop foreign key FILEUPLOAD_SCHOOL__FK;
alter table FILEUPLOAD drop COLUMN school_id;




alter table SCHOOLS add COLUMN public_key NVARCHAR(1024);



alter table USERS modify COLUMN password varchar(1024) NOT NULL;


alter table USERS add COLUMN studyprogram_id int NULL;
alter table USERS 
	add constraint USERS__STUDYPROGRAM__FK
	foreign key (studyprogram_id) 
	references STUDY_PROGRAMS(id) 
	on delete no action 
	on update cascade;





ALTER TABLE INTERNSHIPAGREEMENT_GRADES
	DROP FOREIGN KEY IA_GRADES__INTERNSHIPAGREEMENT_STUDYCOMPETENCES__FK;

ALTER TABLE INTERNSHIPAGREEMENT_GRADES
	DROP FOREIGN KEY INTERNSHIPAGREEMENT_GRADES_ibfk_1;

ALTER TABLE INTERNSHIPAGREEMENT_GRADES
	add constraint IA_GRADES__INTERNSHIPAGREEMENT_STUDYCOMPETENCES__FK2
        FOREIGN KEY (study_competences_id) REFERENCES STUDY_COMPETENCES (id) 
        ON DELETE NO ACTION 
        ON UPDATE CASCADE;




Create table EVALUATION_QUESTIONS(
	id INT NOT NULL AUTO_INCREMENT,
        question NVARCHAR(128) NULL,
        options NVARCHAR(256) NULL,
        show_if INT NULL,
        show_if_value NVARCHAR(128) NULL,
        question_for NVARCHAR(64) NULL,
        ordnum INT NULL,
        school_id NVARCHAR(64) NOT NULL,
	CONSTRAINT EVALUATIONQUESTIONS_PK PRIMARY KEY (id),
        CONSTRAINT EVALUATIONQUESTIONS_SCHOOLS_FK FOREIGN KEY (school_id) REFERENCES SCHOOLS(id)
);

Create table EVALUATION_ANSWERS(
	id INT NOT NULL AUTO_INCREMENT,
        question_id INT NOT NULL,
        internship_agreement_id INT NULL,
        answer NVARCHAR(256) NULL,
        userid NVARCHAR(64) not null,
	CONSTRAINT EVALUATIONANSWERS_PK PRIMARY KEY (id),
        CONSTRAINT EVALUATIONANSWERS_EVALUATIONQUESTIONS_FK FOREIGN KEY (question_id) REFERENCES EVALUATION_QUESTIONS(id),
	CONSTRAINT EVALUATIONANSWERS_INTERNSHIPAGREEMENT_FK FOREIGN KEY (internship_agreement_id) REFERENCES INTERNSHIP_AGREEMENT(id)
);



alter table INTERNSHIP_AGREEMENT add COLUMN mentor NVARCHAR(64) NULL;
alter table INTERNSHIP_AGREEMENT
	add constraint INTERNSHIPAGREEMENT_MENTOR__FK
	foreign key (mentor) 
	references USERS(username) 
	on delete no action 
	on update cascade;


alter table INTERNSHIP_AGREEMENT add COLUMN grade_exam INT NULL;
alter table INTERNSHIP_AGREEMENT add COLUMN grade_final INT NULL;
alter table INTERNSHIP_AGREEMENT add COLUMN grade_date DATE NULL;

alter table INTERNSHIP_AGREEMENT add COLUMN school_organizer NVARCHAR(64) NULL;
alter table INTERNSHIP_AGREEMENT add COLUMN document_number NVARCHAR(64) NULL;
alter table INTERNSHIP_AGREEMENT
	add constraint INTERNSHIPAGREEMENT_SCHOOLORG__FK
	foreign key (school_organizer) 
	references USERS(username) 
	on delete no action 
	on update cascade;











-- novo







alter table USERS add COLUMN first_name TEXT NULL;
alter table USERS add COLUMN last_name TEXT NULL;

alter table ORGANIZATION MODIFY COLUMN name TEXT;
alter table ORGANIZATION MODIFY COLUMN cityname TEXT;
alter table ORGANIZATION MODIFY COLUMN cityzipcode TEXT;
alter table ORGANIZATION MODIFY COLUMN streetname TEXT;
alter table ORGANIZATION MODIFY COLUMN orgtype TEXT;

alter table USERS MODIFY COLUMN phone TEXT;
alter table USERS MODIFY COLUMN email TEXT;
alter table USERS MODIFY COLUMN cityname TEXT;
alter table USERS MODIFY COLUMN cityzipcode TEXT;
alter table USERS MODIFY COLUMN streetname TEXT;
alter table USERS MODIFY COLUMN phone TEXT;




alter table STUDY_PROGRAMS MODIFY COLUMN name TEXT;
alter table STUDY_PROGRAMS MODIFY COLUMN description TEXT;

alter table STUDY_COMPETENCES MODIFY COLUMN name TEXT;
alter table STUDY_COMPETENCES MODIFY COLUMN description TEXT;

alter table AGREEMENT_ARTICLES_TEMPLATE MODIFY COLUMN content TEXT;

alter table INTERNSHIP_AGREEMENT_ARTICLES MODIFY COLUMN content TEXT;

alter table INTERNSHIPAGREEMENT_GRADES MODIFY COLUMN grade_text TEXT;

alter table SCHOOLS MODIFY COLUMN public_key TEXT;

alter table EVALUATION_QUESTIONS MODIFY COLUMN question TEXT;
alter table EVALUATION_QUESTIONS MODIFY COLUMN options TEXT;
alter table EVALUATION_QUESTIONS MODIFY COLUMN show_if_value TEXT;
alter table EVALUATION_QUESTIONS MODIFY COLUMN question_for TEXT;

alter table EVALUATION_ANSWERS MODIFY COLUMN answer TEXT;

alter table INTERNSHIP_AGREEMENT MODIFY COLUMN document_number TEXT;

alter table INTERNSHIP_AGREEMENT ADD COLUMN ects_points INT null;
alter table INTERNSHIP_AGREEMENT ADD COLUMN sum_of_hours INT null;

alter table STUDY_PROGRAMS ADD COLUMN idnumber TEXT;

alter table USERS MODIFY COLUMN password TEXT NOT NULL;














alter table USERS ADD jwt BOOLEAN NULL;



alter table FILEUPLOAD MODIFY COLUMN bytes LONGBLOB;

alter table SCHOOLS add COLUMN public_identifier TEXT;






create table Assignment(
	id INT NOT NULL AUTO_INCREMENT,
        internship_agreement_id INT NOT NULL,
	description TEXT NULL,
        deadline DATE null,
	CONSTRAINT Assignment_PK PRIMARY KEY (id),
	CONSTRAINT Assignment__InternshipAgreement__FK FOREIGN KEY (internship_agreement_id) REFERENCES INTERNSHIP_AGREEMENT(id)
);

create table Assignment_StudyCompetences_Map(
	id INT NOT NULL AUTO_INCREMENT,
        assignment_id INT NOT NULL,
        studycompetence_id INT NOT NULL,
	CONSTRAINT Assignment_StudyCompetences_Map_PK PRIMARY KEY (id),
	CONSTRAINT Ass_StudyComp_Map__Assignment__FK FOREIGN KEY (assignment_id) REFERENCES Assignment(id),
        CONSTRAINT Ass_StudyComp_Map__STUDY_COMPETENCES__FK FOREIGN KEY (studycompetence_id) REFERENCES STUDY_COMPETENCES(id)
);
create table StudentWorklog(
	id INT NOT NULL AUTO_INCREMENT,
        assignment_id INT NOT NULL,
	student_log TEXT NULL,
        date_studentlog DATE null,
	mentor_log TEXT NULL,
        date_mentorlog DATE null,
	CONSTRAINT StudentWorklog_PK PRIMARY KEY (id),
	CONSTRAINT StudentWorklog__Assignment__FK FOREIGN KEY (assignment_id) REFERENCES Assignment(id)
);

